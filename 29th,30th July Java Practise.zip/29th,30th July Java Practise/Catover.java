package com.nisum;

public class Catover extends Animalover {
    public void eat()//here we can give return type as the Animalover or Catover
    {
        System.out.println("cat Eat");
    }
}
