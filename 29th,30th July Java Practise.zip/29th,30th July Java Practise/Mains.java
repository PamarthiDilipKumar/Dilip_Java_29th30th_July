package com.nisum;

public class Mains {
    public static void main(String[] args) {
//        Person p=new Person(10,"Dilip");
//        Person p2=new Person(-9,null);
//        System.out.println(p.getName()+" "+p.getAge());
//        System.out.println(p2.getName()+" "+p2.getAge());

//        Apple a=new Apple();
//        Banana b=new Banana();
//        a.apple();
//        b.banana();

//        Fruits f1=new Bananas();
//        Fruits f2=new Mango();
//        f1.color();
//        f2.color();
//        useFruit(f1);
//        useFruit(f2);
        try{
            useFruit(new Mango());
        }
        catch (AnimalException e){
            throw new RuntimeException(e);
        }
        //useFruit(new Bananas());

    }

    private static void useFruit(Fruits fruit1) throws AnimalException {
        //fruit1.color();
        if (fruit1 instanceof Mango) {
            throw new AnimalException("This is animal exception");
        }
    }

}