package com.nisum;

public class Stringexample {
    public static void main(String[] args) {
        String s1="Hi";
        String s2="Hi";
        System.out.println(s1==s2);
        System.out.println(s1.equals(s2));
        String s3=new String("Hi").intern();
        System.out.println(s1==s3);

    }
}
