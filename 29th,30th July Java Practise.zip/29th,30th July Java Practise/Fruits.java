package com.nisum;

public interface Fruits {
    void color();
}
