package com.nisum;

public class Fruit {
    public Fruit fruit(){
        System.out.println("This is the fruit");
        return null;
    }
}
