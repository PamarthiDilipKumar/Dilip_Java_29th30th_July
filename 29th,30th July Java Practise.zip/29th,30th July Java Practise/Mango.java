package com.nisum;

public class Mango implements Fruits{

    @Override
    public void color() {
        System.out.println("Mango is in yellow color");
    }
}
