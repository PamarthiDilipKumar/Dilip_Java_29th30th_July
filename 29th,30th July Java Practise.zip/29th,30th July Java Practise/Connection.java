package com.nisum;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Connection {
    public Connection getConnection() throws IOException {
        throw new IOException();
    }
}
