package com.nisum;

public class Apple extends Fruit {
    public Apple apple(){
        System.out.println("This is an apple");
        return null;
    }
}
