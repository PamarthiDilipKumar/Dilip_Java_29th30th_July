package com.nisum;

// File: InvalidAgeException.java
public class InvalidAgeException extends Exception {
    public InvalidAgeException(String message, Throwable cause) {
        super(message, cause);
    }

    // Constructor that accepts a message
    public InvalidAgeException(String message) {
        super(message);


    }
}

