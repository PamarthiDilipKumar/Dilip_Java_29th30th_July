package com.nisum;
import java.util.*;
public class Stringexamples {
    private static final String COMPANY ="Nisum";
    public static void main(String[] args) {
        System.out.println(isValid(null));//output: false, private static final String COMPANY =null;System.out.println(isValid("Nisum")): the output will be exception
    }
    public static  boolean isValid(String company){
        return COMPANY.equalsIgnoreCase(company);
    }
}
