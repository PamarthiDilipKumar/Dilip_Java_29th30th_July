package com.nisum;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Exceptionexample {
    public static void main(String[] args) throws IOException {
        Connection connection = new Connection();
        try {
            connection.getConnection();
        } catch (IOException e) {
            throw new IOException(e);
        }
        finally {
            System.out.println("I am finally");
        }
    }
}
