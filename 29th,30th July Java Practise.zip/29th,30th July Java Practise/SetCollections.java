package com.nisum;

import java.util.HashSet;
import java.util.Set;

public class SetCollections {
    public static void main(String[] args) {
        Set<String> names=new HashSet<>();
        names.add("pandu");
        names.add("vishnu");
        names.add("malavika");
        names.add("akshaya");
        names.add("pravalli");
        names.add("pandu");
        names.add("jagu");
        System.out.println(names);
        String s1="pandu";
        String s2="pandu";
        if(s1.equals(s2)){
            System.out.println("Both are equal");
        }
        System.out.println("Hi");
        Employee employee1 =new Employee("pandu",41865);
        Employee employee2 =new Employee("pandu",41865);

        if(employee1.equals(employee2)){
            System.out.println("Both are eqaul");
        }

    }

}
