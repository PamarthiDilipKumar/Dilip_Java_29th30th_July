package com.nisum;

import java.util.*;

public class TestCollections{
    public static void main(String[] args) {
        List<Integer> numbers=new ArrayList<>();
        numbers.add(10);
        numbers.add(20);
        numbers.add(60);
        numbers.add(40);

        //external ietrator
        for(int e:numbers){
            System.out.println(e);
        }
        Collections.sort(numbers);
        List<Employee> employee=new ArrayList<>();
        employee.add(new Employee("Pandu",41865));
        employee.add(new Employee("Vishnu",41871));
        employee.add(new Employee("Jagu",41868));
        //employee.add(new Employee("Pandu",41865));
                //external iterator
        for (int i = 0; i < employee.size(); i++) {
            System.out.println(employee.get(i));
        }
        System.out.println(employee);
        Collections.sort(employee, new EqualComparator());

        System.out.println("\nSorted Employees:");
        System.out.println(employee);
    }
}
