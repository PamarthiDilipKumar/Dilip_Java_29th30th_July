package com.nisum;


public class CustomExceptionExample {

    public static void validateAge(int age) throws InvalidAgeException {

        if (age < 0) {
            // Throw the custom exception with a message
            throw new InvalidAgeException("Age must be positive " + age);
        } else {
            System.out.println("Valid age: " + age);
        }
    }

    public static void main(String[] args) {
        int age=-10;
        try{
            validateAge(age);
        }catch (InvalidAgeException e){
            System.out.println(e.getMessage());
        }
    }
}

