package com.nisum;

import java.util.Objects;

public class Persons {
    public int age;
    public String name;
    public Persons(int age,String name){
        if (age<0){
            throw new IllegalArgumentException(" ");
        }
        Objects.requireNonNull(name, "Age can't be null");
        this.age=age;
        this.name=name;
    }
    public int getAge(){
        return age;
    }
    public String getName(){
        return name;
    }

}
