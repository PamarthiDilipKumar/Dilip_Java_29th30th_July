package com.nisum;

public class Bananas implements Fruits{
    @Override
    public void color() {
        System.out.println("This is the banana which is in yellow color");

    }
}
