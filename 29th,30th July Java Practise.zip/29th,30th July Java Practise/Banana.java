package com.nisum;

public class Banana extends Fruit {
    public Banana banana(){
        System.out.println("This is banana");
        return null;
    }


}
