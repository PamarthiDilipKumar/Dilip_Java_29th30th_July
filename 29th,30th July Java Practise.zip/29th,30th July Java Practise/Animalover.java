package com.nisum;

public class Animalover {
   public void eat()// here we can give the return type as AnimalOver
   {
        System.out.println("animal eat");
    }

}
