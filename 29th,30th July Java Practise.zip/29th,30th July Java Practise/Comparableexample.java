package com.nisum;
import java.util.*;

class Comparableexample implements Comparable<Comparableexample> {
    private int id;
    private String name;
    private String section;

    public Comparableexample(int id, String name, String section) {
        this.id = id;
        this.name = name;
        this.section = section;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSection() {
        return section;
    }

    @Override
    public int compareTo(Comparableexample other) {
        return this.name.compareTo(other.name);
    }

    @Override
    public String toString() {
        return "Student{id=" + id + ", name='" + name + "', section='" + section + "'}";
    }

    public static void main(String[] args) {
        List<Comparableexample> students = new ArrayList<>();
        students.add(new Comparableexample(1, "pandu", "A"));
        students.add(new Comparableexample(2, "vishnu", "B"));
        students.add(new Comparableexample(3, "jaggu", "A"));

        System.out.println("Before sorting:");
        for (Comparableexample student : students) {
            System.out.println(student);
        }

        Collections.sort(students);

        System.out.println("\nAfter sorting by name:");
        for (Comparableexample student : students) {
            System.out.println(student);
        }
    }
}
